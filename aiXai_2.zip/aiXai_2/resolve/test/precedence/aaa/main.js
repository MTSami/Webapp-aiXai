console.log(require('./'));
