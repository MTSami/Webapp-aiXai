# resp-modifier [![Build Status](https://travis-ci.org/shakyShane/resp-modifier.svg?branch=master)](https://travis-ci.org/shakyShane/resp-modifier)

All the good parts from [connect-livereload](https://github.com/intesso/connect-livereload) without
the livereload specific bits & with multiple replacements added.

## Contributing
In lieu of a formal styleguide, take care to maintain the existing coding style. Add unit tests for any new or changed functionality. Lint and test your code using [Gulp](http://gulpjs.com/).

## Release History
_(Nothing yet)_

## License
Copyright (c) 2013 Shane Osbourne
Licensed under the MIT license.
